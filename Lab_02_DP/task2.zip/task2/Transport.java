package task2;

public enum Transport {
	AIR_CARRIER, TRAIN, VAN
}
